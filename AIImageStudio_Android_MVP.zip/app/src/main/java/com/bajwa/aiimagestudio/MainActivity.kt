package com.bajwa.aiimagestudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AIImageStudioApp() }
    }
}

@Composable
fun AIImageStudioApp() {
    var prompt by remember { mutableStateOf("") }
    var negative by remember { mutableStateOf("") }
    var generating by remember { mutableStateOf(false) }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("AI Image Studio") }) }
        ) { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    "Private image-generation controller",
                    style = MaterialTheme.typography.titleMedium
                )

                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp),
                    label = { Text("Prompt") },
                    placeholder = { Text("Describe the image you want...") }
                )

                OutlinedTextField(
                    value = negative,
                    onValueChange = { negative = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Negative prompt") }
                )

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AssistChip(onClick = {}, label = { Text("512 × 512") })
                    AssistChip(onClick = {}, label = { Text("1 image") })
                    AssistChip(onClick = {}, label = { Text("Seed: random") })
                }

                Button(
                    onClick = {
                        generating = true
                        // TODO: connect this action to the selected inference engine.
                    },
                    enabled = prompt.isNotBlank() && !generating,
                    modifier = Modifier.fillMaxWidth().height(54.dp)
                ) {
                    Text(if (generating) "Preparing…" else "✨ Generate")
                }

                if (generating) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text(
                        "Generation engine is not connected yet. This starter app is ready for the next integration step.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                HorizontalDivider()

                Text("Next build stages", style = MaterialTheme.typography.titleSmall)
                Text("• Connect an Android-compatible inference backend")
                Text("• Add model download/management")
                Text("• Add generated-image preview and saving")
                Text("• Add gallery/history")
                Text("• Add image-to-image and upscaling")
            }
        }
    }
}
